<!doctype html>
</html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="csrf-token" content="{{ csrf_token() }}" />
        <!-- Styles -->
    <link href="{{ asset('assets/css/bootstrap.min.css') }}" rel="stylesheet">

<style>
    table, th, td {
        border: 1px solid black;
    }
</style>

</head>
<body>
 <div class="modal fade" id="exampleModal2" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content" style="color:black;">
      <div class="modal-header">
        <h1 class="modal-title fs-5" id="exampleModalLabel">New Case Entry</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div id="bd" class="modal-body">
<div>
<h4>Select particular Case</h4>
<table>
<thead>
<th>Date</th>
<th>ID</th>
<th>Patient Name</th>
<th>Action</th>
</thead>
<tbody id='tbody11'>
@foreach ($casefile as $case)
<tr>
<td id="dt1">{{ $case->case_dt }}</td>
<td id="id1">{{ $case->patient->id }}</td>
<td id="name1">{{ $case->patient->pt_name }}</td>
<td><button type="button" id="select1">Select</button></td>
</tr>
@endforeach
</tbody>
</table>
Name :
<input type="text" id="id11" value="0" />
<input type="text" id="txt1" value="xyz" />
</div>
        
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
 
      </div>
    </div>
  </div>

</div>
<!-- Patient Choice Layout-->
{{-- <div>
<h4>Select particular Case</h4>
<table>
<thead>
<th>Date</th>
<th>Patient Name</th>
<th>Action</th>
</thead>
<tbody id='tbody1'>
<tr>
<td id="dt1">2024-01-10</td>
<td id="name1">Shabbir</td>
<td><button type="button" id="select1">Select</button></td>
</tr>
<tr>
<td id="dt1">2000-01-10</td>
<td id="name1">Hussain</td>
<td><button type="button" id="select1">Select</button></td>
</tr>
@foreach ($casefile as $case)
<tr>
<td id="dt1">{{ $case->case_dt }}</td>
<td id="name1">{{ $case->patient->pt_name }}</td>
<td><button type="button" id="select1">Select</button></td>
</tr>
@endforeach
</tbody>
</table>
Name :
<input type="text" id="txt1" value="xyz" />
</div>
 --}}    <script src="http://code.jquery.com/jquery-3.4.1.js"></script>
<script src="{{ asset("frontend/js/jquery.datetimepicker.full.min.js") }}">
</script>

    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.6/dist/umd/popper.min.js" integrity="sha384-wHAiFfRlMFy6i5SRaxvfOCifBUQy1xHdJ/yoi7FRNXMRBu5WHdZYu1hA6ZOblgut" crossorigin="anonymous"></script>
   <!-- Scripts -->
    <script src="{{ asset('assets/js/bootstrap.bundle.min.js') }}" ></script>
 <script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });

</script>

</body>
</html>